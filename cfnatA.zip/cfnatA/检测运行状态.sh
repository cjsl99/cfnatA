#!/bin/bash

pid=$(ps -ef | grep "[c]fnat" | grep -v "grep" | awk '{print $2}')


if [ -n "$pid" ]; then
  echo "找到 cfnat 进程，PID: $pid"
  echo "cfnat 运行中，如果想结束运行请执行结束运行脚本"
else
  echo "cfnat 没有运行"
fi