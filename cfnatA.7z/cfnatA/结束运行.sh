#!/bin/bash

# 查找程序名为 cfnat 的进程ID
pid=$(ps -ef | grep "cfnat" | grep -v "grep" | awk '{print $2}')

# 检查是否找到了进程ID
if [ -n "$pid" ]; then
  echo "找到 cfnat 进程，PID: $pid"
  
  # 结束该进程
  kill -9 $pid
  
  echo "已结束 cfnat 进程。"
else
  echo "未找到 cfnat 进程。"
fi